#ifndef SOLVE
#define SOLVE
#include <math.h>
#include <stdbool.h>
#define minv 0.000001

struct equation_params
{
    double a;
    double b;
    double c;
};

struct roots
{
    double x1;
    double x2;
};

typedef enum solutionCount 
{
    EMPTYSET = -1,
    ZERO,        
    ONE, 
    TWO, 
    INF
} solutionCount_t;

solutionCount_t solve_equation (equation_params* parametrs, roots* roots);
int check_is_zero (double value);
solutionCount_t solve_square (equation_params* parametrs, roots* roots);
solutionCount_t solve_line_equation (roots* roots, double parametr1, double parametr2);

#endif