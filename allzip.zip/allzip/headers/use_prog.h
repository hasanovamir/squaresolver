#ifndef USEPROG
#define USEPROG
#include <string.h>

int use_prog (void);

#endif