#ifndef INPUT
#define INPUT
#include <stdio.h>
#include <ctype.h>
#include "solve.h"

int read_coeffs (equation_params* parametrs);
int clean_buffer (void);
double get_num (void);
int check_new_str (void);

#endif