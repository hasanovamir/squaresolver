#include <assert.h>
#include "../headers/input.h"
#include "../headers/print.h"
#include "../headers/solve.h"
#include "../headers/test.h"
#include "../headers/use_prog.h"


solutionCount_t solve_equation ( equation_params* parametrs, roots* roots)
{   
    assert (parametrs != NULL);
    assert (roots != NULL);

    if (check_is_zero (parametrs->a))
    {
        return solve_line_equation (roots, parametrs->b, parametrs->c);
    }
    else if (check_is_zero (parametrs->c))
    {
        solve_line_equation (roots, parametrs->a, parametrs->b); 

        return TWO;
    }
    else 
    {
        return solve_square (parametrs, roots);
    }
}


int check_is_zero (double value)
{
        return fabs (value) < minv;
}
 

solutionCount_t solve_line_equation (roots* roots, double parametr1, double parametr2)
{
        if (check_is_zero (parametr1))
        {
            if (check_is_zero (parametr2))
                return INF;
            else
                return EMPTYSET;
        }
        else
        {
            roots->x1 = - parametr2 / parametr1;

            return ONE;
        }    
}


solutionCount_t solve_square (equation_params* parametrs, roots* roots)
{
    double disc = 0, sqrtd = 0;

    disc = parametrs->b * parametrs->b - 4 * parametrs->a * parametrs->c;

    if (check_is_zero (disc))
    {
        roots->x1 = - parametrs->b / 2 / parametrs->a;

        return ONE;
    }
    else if (disc > minv)
    {
        sqrtd = sqrt (disc);

        roots->x1 = (- parametrs->b + sqrtd) / 2 / parametrs->a;
        roots->x2 = (- parametrs->b - sqrtd) / 2 / parametrs->a;

        return TWO;
    }
    else
        {
            return ZERO;
        }
}