#include <TXlib.h>
#include "../headers/input.h"
#include "../headers/print.h"
#include "../headers/solve.h"
#include "../headers/test.h"
#include "../headers/use_prog.h"


// условную компиляцию для запуска теста при дебаге
//2 версии для разра и для usera 
//фдаги компиляции

int main (void)
{
    
#ifdef DEBUG
        
    need_to_test();

#endif

    printf ("This program is disigned to solve square equations\n");

    use_prog ();

    return 0;
}