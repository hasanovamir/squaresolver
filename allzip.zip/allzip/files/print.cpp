#include "../headers/input.h"
#include "../headers/print.h"
#include "../headers/solve.h"
#include "../headers/test.h"
#include "../headers/use_prog.h"


int print_solution (solutionCount_t solutionCount, const equation_params* parametrs, const roots* roots)
{
    printf ("Your equation: %.3lf X^2 + %.3lf X + %.3lf = 0\n",
        parametrs->a, parametrs->b, parametrs->c);

    switch (solutionCount) 
    {
        case EMPTYSET:
            printf ("Empty set\n");
            break;
        case INF:
            printf ("There are too many solution\n");
            break;
        case ZERO:
            printf ("There`s no solution\n");
            break;
        case ONE:
            printf ("There`s one solution: x = %.3lf\n", roots->x1);
            break;
        case TWO:
            printf ("There are 2 solution: x_1 = %.3lf, x_2 = %.3lf\n", roots->x1, roots->x2);
        default:
            ;
    }
    
    return 0;
}


bool need_to_continue (void)
{
    printf ("Woude you continue?\n");
    printf ("Print \"Y\" to continue or \"N\" to break: ");

    clean_buffer ();

    do
    {
        int answer = getchar ();

        if (answer == '\n')
        {
            printf ("write Y or N!!!\nAnswer:");
            continue;
        }

        clean_buffer ();

        if (tolower (answer) == 'y')
        {
            printf ("Enter next parametrs: ");
            return true;
        }

        if (tolower (answer) == 'n')
        {
            return false;
        }

        printf ("write Y or N!!!\nAnswer:");

    } while (true);
}