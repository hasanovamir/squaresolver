#include "../headers/input.h"
#include "../headers/print.h"
#include "../headers/solve.h"
#include "../headers/test.h"
#include "../headers/use_prog.h"


int read_coeffs (equation_params* parametrs)
{
    parametrs->a = get_num();
    check_new_str ();
    parametrs->b = get_num();
    check_new_str ();
    parametrs->c = get_num ();

    return 0;
}


int clean_buffer (void)
{
    int trash = 0;

    while ( (trash = getchar ()) != '\n')
    {
        if (trash == EOF)
        {
            return EOF;
        }
    }

    return 0;
}


double get_num (void)
{
    double read_value = 0;

    while (true)
    {
        if (scanf ("%lf", &read_value))
        {
                return read_value;
        }
        else
        {
            clean_buffer ();
            printf (RED "ERROR: " RESET);
            printf ("try to enter again: ");
        }
    }
}


int check_new_str (void)
{   
    int a = 0;

    if ((a = getchar ()) == '\n')
    {
        printf ("Write next float numbers: ");
    }
    else if (a != ' ')
    {
        clean_buffer ();
        printf ("Write next FLOAT nubmer: ");
    }
    
    return 0;
}