#include <TXlib.h>
#include "input.h"
#include "print.h"
#include "solve.h"
#include "test.h"

int main (void)
{
    equation_params parametrs = {};
    roots roots = {};

    printf ("This program is disigned to solve square equations\n");

    need_to_test ();     
    
    printf ("Enter 3 float numbers:");

    int answer = 0;
  
    do
    {   read_coeffs(&parametrs);
        print_solution (solve_equation (&parametrs, &roots), &parametrs, &roots);
        answer = need_to_continue ();
    } while (answer != 0);

    printf ("Thanks you for using!!!");
    return 0;
}