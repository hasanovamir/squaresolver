#include "input.h"
#include "print.h"
#include "test.h"
#include "solve.h"


int need_to_test (void)
{
    int status = 0;

    printf ("Woude you start testing program?\n");
    printf ("Print \"Y\" to start testing program\n");
    printf ("Print \"N\" to use equation solver: ");

    do
    {
        int answer = getchar ();

        if (answer == '\n')
        {
            printf ("write Y or N!!!\nAnswer:");
            continue;
        }

        clean_buffer ();

        if (tolower (answer) == 'y')
        {
            status = 1;
        }
        else if (tolower (answer) == 'n')
        {
            status = -1;
        }
        else
        {
            printf ("write Y or N!!!\nAnswer:");
        }

    } while (status == 0);
    if (status == 1)
    {
        testing_solver ();
    }
    return 0;
}


int testing_solver (void)
{

    equation_params test_parametrs[5] = { { 0,  0,  0},
                                                 { 0,  2, -4},
                                                 { 1,  4,  4},
                                                 { 1, -5,  6},
                                                 { 1,  1,  5} };


    roots cor_roots[5] = {  { 0, 0},
                            { 2, 0},
                            {-2, 0},
                            { 3, 2},
                            { 0, 0}  };

    for (int i = 0; i < 5; i++)
    {
        roots test_roots = {};
        solve_equation (&test_parametrs[i], &test_roots);

        if (!check_is_zero (cor_roots[i].x1 - test_roots.x1) || !check_is_zero (cor_roots[i].x2 - test_roots.x2) )
        {    
            printf (RED "Test failed\n" RESET);
        }
        else
        {
            printf (GREEN "Test was complited successfully\n" RESET);
        }
    }
    return 0;
}