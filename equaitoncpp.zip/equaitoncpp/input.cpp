#include "input.h"
#include "print.h"
#include "test.h"
#include "solve.h"

int read_coeffs (equation_params* parametrs)
{
    parametrs->a = get_num();
    if (getchar () == '\n')
    {
        printf ("Write next float numbers: ");
    }
    parametrs->b = get_num();
    if (getchar () == '\n')
    {
        printf ("Write next float numbers: ");
    }
    parametrs->c = get_num ();
    return 0;
}


int clean_buffer (void)
{
    int trash = 0;
    while ( (trash = getchar () ) != '\n')
    {
        if (trash == EOF)
            return EOF;
    }
    return 0;
}


double get_num (void)
{
    double read_value = 0;
    while (true)
    {
        if (scanf ("%lf", &read_value) == 1)
        {
                return read_value;
        }
        else
        {
            clean_buffer ();
            printf (RED "ERROR: " RESET);
            printf ("try to ender again: ");
        }
    }
}