#ifndef TEST
#define TEST
#define GREEN "\033[32m"
#define RED "\033[31m"
#define RESET "\033[0m"
int testing_solver   (void);
int need_to_test     (void);
#endif