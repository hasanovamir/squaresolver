#ifndef PRINT
#define PRINT
int print_solution   (solutionCount_t solutionCount, const equation_params* parametrs, const roots* roots);
bool need_to_continue (void);
#endif